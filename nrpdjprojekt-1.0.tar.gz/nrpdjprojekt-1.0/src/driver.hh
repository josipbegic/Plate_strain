template<class GV>
void driver(const GV& gv) {
	// <<<1>>> Choose domain and range field type
	typedef typename GV::Grid::ctype Coord;
	typedef double Real;
	const int dim = GV::dimension;
	//const int dimw = GV::dimensionworld;
	
	// <<<2>>> Make grid function space
	typedef Dune::PDELab::P1LocalFiniteElementMap<Coord, Real, dim> FEM0;
    FEM0 fem0;
    typedef Dune::PDELab::P1LocalFiniteElementMap<Coord, Real, dim> FEM1;
    FEM1 fem1;
    
	typedef Dune::PDELab::ConformingDirichletConstraints CON; // constraints class //ipak imam constraints jer je na krugu dirichlet
	//typedef Dune::PDELab::NoConstraints CON;
	typedef Dune::PDELab::ISTLVectorBackend<2> VBE;
	
	typedef Dune::PDELab::GridFunctionSpace<GV, FEM0, CON, VBE> GFS0;
	GFS0 gfs0(gv, fem0);
	typedef Dune::PDELab::GridFunctionSpace<GV, FEM1, CON, VBE> GFS1;
	GFS1 gfs1(gv, fem1);
	
	typedef Dune::PDELab::GridFunctionSpaceBlockwiseMapper M;
	typedef Dune::PDELab::CompositeGridFunctionSpace<M, GFS0, GFS1> GFS;
	GFS gfs(gfs0, gfs1);
	
	typedef Dune::PDELab::GridFunctionSubSpace<GFS, 0> U0SUB;
	U0SUB u0sub(gfs);
	typedef Dune::PDELab::GridFunctionSubSpace<GFS, 1> U1SUB;
	U1SUB u1sub(gfs);
	
	BCTypeParam bctype; // boundary condition type OVO MI DEFINIRAMO
	typedef typename GFS::template ConstraintsContainer<Real>::Type CC;
	CC cc;
	Dune::PDELab::constraints(bctype, gfs, cc); // assemble constraints
	std::cout << "constrained dofs=" << cc.size() << " of " << gfs.globalSize() << std::endl;
	
	
	// <<<3>>> Make grid operator
	// evaluate parameters
	//double E, ni, mi, lambda;
	//E = 5e9;
	//ni = 0.3;
	//mi = E / (2 * (1 + ni));
	//lambda = (E * ni) / ((1 + ni) * (1 - 2 * ni));
	
	typedef Example02LocalOperator<BCTypeParam> LOP; // operator including boundary
	int intorder = 2;
	LOP lop(bctype, intorder);
	typedef VBE::MatrixBackend MBE;
	
	typedef Dune::PDELab::GridOperator<
		GFS,GFS,        /* ansatz and test space */
		LOP,            /* local operator */
		MBE,            /* matrix backend */
		Real,Real,Real, /* field types for domain, range and jacobian */
		CC,CC           /* constraints transformation for ansatz and test space */
	> GO;
	GO go(gfs,cc,gfs,cc,lop);
	
	// <<<4>>> Make FE function extending Dirichlet boundary conditions
	typedef typename GO::Traits::Domain U;
	U u(gfs, 0.0);
	typedef BCExtension<GV, Real> G; // boundary value + extension OVO MI DEFINIRAMO
	G g(gv);
	Dune::PDELab::interpolate(g, gfs, u); // interpolate coefficient vector
	
	// <<<5>>> Select a linear solver backend
	typedef Dune::PDELab::ISTLBackend_SEQ_BCGS_SSOR LS;
	LS ls(5000, true);
	
	// <<<6>>> assemble and solve linear problem
	typedef Dune::PDELab::StationaryLinearProblemSolver<GO, LS, U> SLP;
	SLP slp(go, u, ls, 1e-10);
	slp.apply();
	
	// <<<7>>> graphical output
	typedef Dune::PDELab::DiscreteGridFunction<U0SUB, U> U0DGF;
	U0DGF u0dgf(u0sub, u);
	typedef Dune::PDELab::DiscreteGridFunction<U1SUB, U> U1DGF;
	U1DGF u1dgf(u1sub, u);
	Dune::VTKWriter<GV> vtkwriter(gv, Dune::VTK::conforming);
	vtkwriter.addVertexData(new Dune::PDELab::VTKGridFunctionAdapter<U0DGF>(u0dgf, "u1"));
	vtkwriter.addVertexData(new Dune::PDELab::VTKGridFunctionAdapter<U1DGF>(u1dgf, "u2"));
	vtkwriter.write("ispis",Dune::VTK::appendedraw);
	
}

