#include <dune/geometry/quadraturerules.hh>
#include <dune/geometry/referenceelements.hh>

#include <dune/pdelab/localoperator/defaultimp.hh>
#include <dune/pdelab/localoperator/flags.hh>
#include <dune/pdelab/localoperator/pattern.hh>

/** a local operator for solving the equation
 *
 *   - \Delta u + a*u = f   in \Omega
 *                  u = g   on \Gamma_D\subseteq\partial\Omega
 *  -\nabla u \cdot n = j   on \Gamma_N = \partial\Omega\setminus\Gamma_D
 *
 * with conforming finite elements on all types of grids in any dimension
 *
 * \tparam BCType parameter class indicating the type of boundary condition
 */
template<class BCType>
class Example02LocalOperator : // derivacijska lista -- jakobijane i pattern računa PDELab
  public Dune::PDELab::NumericalJacobianApplyVolume<Example02LocalOperator<BCType> >,
  public Dune::PDELab::NumericalJacobianVolume<Example02LocalOperator<BCType> >,
  public Dune::PDELab::NumericalJacobianApplyBoundary<Example02LocalOperator<BCType> >,
  public Dune::PDELab::NumericalJacobianBoundary<Example02LocalOperator<BCType> >,
  public Dune::PDELab::FullVolumePattern,
  public Dune::PDELab::LocalOperatorDefaultFlags
{
public:
	// Zastavice koje signaliziraju da na svakom elementu treba zvati: 
	enum {doPatternVolume = true};  // metodu za računanje patterna (iz volumnih doprinosa)
	enum {doAlphaVolume = true};    // alpha_volume
	enum {doAlphaBoundary = true};  // alpha_boundary         
	
	Example02LocalOperator(const BCType& bctype_, // boundary cond.type
                         unsigned int intorder_=2) :
    bctype( bctype_ ), intorder( intorder_ )
  {}

	
	// volume integral depending on test and ansatz functions
	// eg   = element 
	// lfsu = lokalni prostor funkcija za rješenje
	// lfsv = lokalni prostor funkcija za test funkciju
	// x    = vektor koeficijenata rješenja 
	// r    = lokalni rezidual
	template<typename EG, typename LFSU, typename X, typename LFSV, typename R>
	void alpha_volume(const EG& eg, const LFSU& lfsu, const X& x, const LFSV& lfsv, R& r) const {
		// select the two components (assume Galerkin scheme U=V)
		typedef typename LFSU::template Child<0>::Type LFSU0; // extract components
		const LFSU0& lfsu0 = lfsu.template getChild<0>();     // with template magic
		typedef typename LFSU::template Child<1>::Type LFSU1;
		const LFSU1& lfsu1 = lfsu.template getChild<1>();
		
		// dimensions
		const int dim = EG::Geometry::dimension;
		const int dimw = EG::Geometry::dimensionworld;
		
		// extract some types
		typedef typename LFSU0::Traits::FiniteElementType::Traits::LocalBasisType::Traits::DomainFieldType DF;
		typedef typename LFSU0::Traits::FiniteElementType::Traits::LocalBasisType::Traits::RangeFieldType RF;
		typedef typename LFSU0::Traits::FiniteElementType::Traits::LocalBasisType::Traits::JacobianType Jacobian;
		typedef typename LFSU0::Traits::FiniteElementType::Traits::LocalBasisType::Traits::RangeType Range;
		typedef Dune::FieldVector<RF, dimw> Gradient;
		typedef typename LFSU::Traits::SizeType size_type;
			double E, ni, mi, lambda;
			E = 5e9;
			ni = 0.3;
			mi = E / (2 * (1 + ni));
			lambda = (E * ni) / ((1 + ni) * (1 - 2 * ni));
			double f0 =0, f1 = 0;
				
				
		// select quadrature rule
		Dune::GeometryType gt = eg.geometry().type();
		const Dune::QuadratureRule<DF, dim>& rule = Dune::QuadratureRules<DF, dim>::rule(gt, intorder);
		
		// loop over quadrature points
		for (typename Dune::QuadratureRule<DF, dim>::const_iterator
		     it = rule.begin(); it != rule.end(); ++it) {
			// evaluate basis functions on reference element
			std::vector<Range> phi0(lfsu0.size());
			lfsu0.finiteElement().localBasis().evaluateFunction(it->position(), phi0);
			std::vector<Range> phi1(lfsu1.size());
			lfsu1.finiteElement().localBasis().evaluateFunction(it->position(), phi1);
			
			// compute u0, u1 at integration point
			RF u0 = 0.0;
			for (size_type i = 0; i < lfsu0.size(); ++i)
				u0 += x(lfsu0, i) * phi0[i];
			RF u1 = 0.0;
			for (size_type i = 0; i < lfsu1.size(); ++i)
				u1 += x(lfsu1, i) * phi1[i];
			
			// evaluate gradient of basis functions on reference element
			std::vector<Jacobian> js0(lfsu0.size());
			lfsu0.finiteElement().localBasis().evaluateJacobian(it->position(), js0);
			std::vector<Jacobian> js1(lfsu1.size());
			lfsu1.finiteElement().localBasis().evaluateJacobian(it->position(), js1);
			
			// transform gradients from reference element to real element
			const Dune::FieldMatrix<DF, dimw, dim>& jac = eg.geometry().jacobianInverseTransposed(it->position());
			std::vector<Gradient> gradphi0(lfsu0.size());
			for (size_type i = 0; i < lfsu0.size(); ++i)
				jac.mv(js0[i][0], gradphi0[i]);
			std::vector<Gradient> gradphi1(lfsu1.size());
			for (size_type i = 0; i < lfsu1.size(); ++i)
				jac.mv(js1[i][0], gradphi1[i]);
			
			// compute gradient of u0, u1
			Gradient gradu0(0.0);
			for (size_type i = 0; i < lfsu0.size(); ++i)
				gradu0.axpy(x(lfsu0, i), gradphi0[i]);
			Gradient gradu1(0.0);
			for (size_type i = 0; i < lfsu1.size(); ++i)
				gradu1.axpy(x(lfsu1, i), gradphi1[i]);
			
			// integrate grad u * grad phi_i - f * phi_i
			RF factor = it->weight() * eg.geometry().integrationElement(it->position());
			
			for (size_type i = 0; i < lfsu0.size(); ++i)
				r.accumulate(lfsu0, i, ((lambda * (gradu0[0] + gradu1[1]) + 2 * mi * gradu0[0]) * gradphi0[i][0] + mi * (gradu1[0] + gradu0[1]) * gradphi0[i][1] - f0 * phi0[i]) * factor);
			for (size_type i = 0; i < lfsu1.size(); ++i)
				r.accumulate(lfsu1, i, (mi * (gradu1[0] + gradu0[1]) * gradphi1[i][0] + (lambda * (gradu0[0] + gradu1[1]) + 2 * mi * gradu1[1]) * gradphi1[i][1] - f1 * phi1[i]) * factor);
				
			}
	}
	
	// boundary integral
	// ig     = intersection (= stranica elementa)
	// lfsu_s = lokalni prostor funkcija na stranici za rješenje
	// lfsu_v = lokalni prostor funkcija na stranici za test funkciju 
	// x_s    = vektor koeficijenata rješenja (na stranici)
	// r_s    = rezidual (na stranici)
	template<typename IG, typename LFSU, typename X, typename LFSV, typename R>
	void alpha_boundary (const IG& ig, const LFSU& lfsu_s, const X& x_s,
	const LFSV& lfsv_s, R& r_s) const {
		// select the two components (assume Galerkin scheme U=V)
		typedef typename LFSU::template Child<0>::Type LFSU0; // extract components
		const LFSU0& lfsu_s0 = lfsu_s.template getChild<0>();     // with template magic
		typedef typename LFSU::template Child<1>::Type LFSU1;
		const LFSU1& lfsu_s1 = lfsu_s.template getChild<1>();
		
		// some types
		typedef typename LFSU0::Traits::FiniteElementType::Traits::LocalBasisType::Traits::DomainFieldType DF;
		typedef typename LFSU0::Traits::FiniteElementType::Traits::LocalBasisType::Traits::RangeFieldType RF;
		typedef typename LFSU0::Traits::FiniteElementType::Traits::LocalBasisType::Traits::RangeType Range;
		typedef typename LFSU::Traits::SizeType size_type;
		
		// dimensions
		const int dim = IG::dimension;
		
		// select quadrature rule for face
		Dune::GeometryType gtface = ig.geometryInInside().type();
		const Dune::QuadratureRule<DF, dim - 1>& rule = Dune::QuadratureRules<DF, dim - 1>::rule(gtface, intorder);
		
		// loop over quadrature points and integrate normal flux
		for (typename Dune::QuadratureRule<DF, dim - 1>::const_iterator it = rule.begin(); it != rule.end(); ++it) {
			// skip rest if we are on Dirichlet boundary
			if (bctype.isDirichlet(ig, it->position()))
				continue;
			
			// position of quadrature point in local coordinates of element
			Dune::FieldVector<DF, dim> local = ig.geometryInInside().global(it->position());
			
			// evaluate basis functions at integration point
			std::vector<Range> phi0(lfsu_s0.size());
			lfsu_s0.finiteElement().localBasis().evaluateFunction(local, phi0);
			std::vector<Range> phi1(lfsu_s1.size());
			lfsu_s1.finiteElement().localBasis().evaluateFunction(local, phi1);
			
			// evaluate flux boundary condition
			Dune::FieldVector<RF, dim> globalpos = ig.geometry().global(it->position());
			RF g0=0;
			RF g1=0;
			
			double E, ni, mi, lambda;
			E = 5e9;
			ni = 0.3;
			mi = E / (2 * (1 + ni));
			lambda = (E * ni) / ((1 + ni) * (1 - 2 * ni));
			
			if (globalpos[0]<1e-6)
				g0=-2*(mi+lambda)*1e-2;
		
			if (globalpos[0]>1-1e-6)
				g0=2*(mi+lambda)*1e-2;
				
			
			if (globalpos[1]<1e-6)
				g1=-2*(mi+lambda)*1e-2;
			
			if (globalpos[1]>1-1e-6)
				g1=2*(mi+lambda)*1e-2;		        
			
			
			// integrate -g * phi
			RF factor = it->weight() * ig.geometry().integrationElement(it->position());
			
			for (size_type i = 0; i < lfsu_s0.size(); ++i)
				r_s.accumulate(lfsu_s0, i, -g0 * phi0[i] * factor);
			for (size_type i = 0; i < lfsu_s1.size(); ++i)
				r_s.accumulate(lfsu_s1, i, -g1 * phi1[i] * factor);
		}
	}
	
private:
	const BCType& bctype;
	unsigned int intorder;
	double mi, lambda;
};
