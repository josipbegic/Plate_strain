#include <dune/common/fvector.hh>

#include <dune/pdelab/common/function.hh>
#include <dune/pdelab/constraints/constraintsparameters.hh>

// Klasa mora proširivati klasu PDELab::DirichletConstraintsParameters
// i u njoj prerađuje metodu isDirichlet() odlučuje je li neka točka 
// na Dirichletovoj granici ili nije. 
class BCTypeParam : public Dune::PDELab::DirichletConstraintsParameters {
public:
	// intersection = stranica elementa (u 3D) ili brid elementa (u 2D)
	// coord        = lokalne koordinate točke na "intersectionu" koja se ispituje
	// povratna vrijednost: true ako je točka na Dirichletovoj granici
	//                      false ako nije. 
	template<typename I>
	bool isDirichlet(const I & intersection, const Dune::FieldVector<typename I::ctype, I::dimension - 1> & coord) const {
		// Globalne koordinate točke (uočite da su dimenzije lokalne i globalne točke različite )
		Dune::FieldVector<typename I::ctype, I::dimension> xg = intersection.geometry().global( coord );
			
		if(xg[0]>0.2 && xg[0]<0.8 && xg[1]>0.2 && xg[1]<0.8) //ako smo na krugu, rubni uvjet je dirichletov
			return true;

		
		return false;
	}
};
