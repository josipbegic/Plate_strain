/*  Klasa koja određuje vrijednost Dirichletovog rubnog uvjeta i 
    njegovo proširenje na čitavu domenu. 
    Template parametri:
       GV = GridView
       RF = Range Field Type (tip kojim su predstavljeni elementi slike funkcije)
       
       Treći parametar u GridFunctionTraits je dimenzija slike funkcije (1 jer su 
       naše funkcije skalarne). Ta se dimenzija ponavlja u zadnjem parametru 
       GridFunctionTraits klase.
*/
template<typename GV, typename RF>
class BCExtension
  : public Dune::PDELab::GridFunctionBase<Dune::PDELab::
           GridFunctionTraits<GV, RF, 2, Dune::FieldVector<RF, 2> >, BCExtension<GV,RF> > {
 // Klasa čuva referencu na GridView objekt.
	const GV& gv;
public:
	typedef Dune::PDELab::GridFunctionTraits<GV, RF, 2, Dune::FieldVector<RF, 2> > Traits;
	
	// Konstruktor samo uzima referencu na  GridView objekt. 
	BCExtension (const GV& gv_) : gv(gv_) {}
	
	// Izračunaj Dirichletovu vrijednost na elementu. Ako točka nije na 
	// Dirichletovoj granici, onda funkcija daje proširenje Dirichletovog rubnog
	// uvjeta na čitavu domenu. To je proširenje u osnovi proizvoljno. 
	// e      = element 
	// xlocal = lokalne koordinate točke u kojoj se računa Dirichletova vrijednost
	// y      = izračunata Dirichletova vrijednost
	inline void evaluate (const typename Traits::ElementType& e, const typename Traits::DomainType& xlocal, typename Traits::RangeType& y) const {
		//const int dim = Traits::GridViewType::Grid::dimension;
		typedef typename Traits::GridViewType::Grid::ctype ctype;
		
		y = 0.0;
		
		return;
	}

	// Vrati referencu na GridView
	inline const GV& getGridView () {return gv;}
};
